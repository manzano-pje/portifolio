/*
==============================================================================
Nome: Education.ts
Tipo: TYPE
Responsabilidade: Define os tipos e contratos TypeScript utilizados no projeto.
==============================================================================
*/

