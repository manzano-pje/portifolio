<!--
==============================================================================
Nome: CertificateCard.vue
Tipo: COMPONENT
Responsabilidade: Renderiza um componente visual reutilizável para a interface.
Padrão: BEM
==============================================================================
-->

