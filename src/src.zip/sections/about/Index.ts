/*
==============================================================================
Nome: Index.ts
Tipo: CONFIG
Responsabilidade: Define o arquivo correspondente dentro da arquitetura do projeto.
==============================================================================
*/

export { default } from './AboutSection.vue'